
domDocument *  XML_SimpleParseDocument ( char *xml, int ignoreWhiteSpaces, 
                                         char *baseURI, char *extResolver,
                                         int *pos, char **errStr );
