
domDocument *  HTML_SimpleParseDocument ( char *html, int ignoreWhiteSpaces, 
                                          int *pos, char **errStr );
