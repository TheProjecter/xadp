#pragma once on#include "tclMacCommonPch.h"#define USE_TCL_STUBS 1#define TDOM_NO_UNKNOWN_CMD#define VERSION "0.8.1"
