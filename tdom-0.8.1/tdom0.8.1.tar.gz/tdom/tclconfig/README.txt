The other files in this directory are the functional core of the Tcl
Extension Architecture (TEA). For more information on TEA see:

	http://www.tcl.tk/doc/tea/

The other files in this directory are out of the tclconfig directory
of:

http://cvs.sourceforge.net/viewcvs.py/tcl/sampleextension/

from 2006-08-26 (TEA 3.5).
