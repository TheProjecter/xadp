#if __POWERPC__
#include "MW_TclTestHeaderPPC"
#elif __CFM68K__
#include "MW_TclTestHeaderCFM68K"
#else
#include "MW_TclTestHeader68K"
#endif
